export module SubFn {
    export class SubFn {
     one = 1;
    }
}