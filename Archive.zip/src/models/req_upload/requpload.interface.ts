export interface FileUploadbyFormQuery {
    file_obj_name: string,
    file_size: number
}