export interface GGLoginauthBody {
    idToken: string
}